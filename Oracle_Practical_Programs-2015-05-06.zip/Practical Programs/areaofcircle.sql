set serveroutput ON

DECLARE

pi constant number(4,2):=3.14;
radius number(5);
area number(14,2);

BEGIN

radius:=3;

WHILE radius<=7
LOOP
area:=pi+power(radius,2);
INSERT into areas VALUES(radius,area);
radius:=radius+1;
END LOOP;

--DBMS_OUTPUT.PUT_LINE('The given number is: '||given_number);
--DBMS_OUTPUT.PUT_LINE('The inverted number is: '||inverted_number);
--comment																																					
END;
/