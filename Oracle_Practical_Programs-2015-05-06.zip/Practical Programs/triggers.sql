/* Triggers

A trigger has 3 basic parts:
	1. A triggering event or statement.
	2. A trigger restriction
	3. A trigger action
	
	Triggering event or statement: It is a SQL statement that causes a trigger to be fired. It can be insert, update or delete statement for a specific table.

	Trigger restriction: It specifies a boolean expression that must be true for the trigger to fire. It is an option available for triggers that are fired for each row. Its function is to conditionally control the execution of a trigger. A trigger restriction is specified using a when clause.

	Trigger Action: It is the PL/SQL code to be executed when a triggering statement is encountered and any trigger restriction evaluates to true. The PL/SQL block can contain SQL and PL/SQL statements, can defined PL/SQL language constructs and can call stored procedures. Additionally, for row triggers the statements the PL/SQL block have access to calumn values (:new & :old) of the current row being processed.

Types of Triggers:
	1. Row Triggers
	2. Statement Triggers
	3. Before Triggers
	4. After Triggers
	5. Combination Triggers
	
Syntax:
	Create or Replace Trigger [scheme] <TriggerName>
	{Before, After}
	{Select, Insert, Update [of column]}
	ON [Scheme]<TableName>
	[Referencing {OLD As old, NEW As new}]
	[For Each Row[When Condition]]
	
	Declare
	<variable declarations>
	<constant declarations>
	
	Begin
	<PL/SQL subprogram body>
	
	Exception
	<Exception PL/SQL block>
	
	End;
	/ 
	
SET SERVEROUTPUT ON

OR replace recreates the trigger if it aleady exists.
Scheme is the schema which contains the trigger.
TriggerName is the name of the trigger to be created
Before indicates that the oracle engine fires the trigger before executing the triggering statement.
After indicates that the oracle engine fires the trigger after executing the triggering statement.
Delete indicates that the oracle engine fires the trigger whenever a delete statement a row from the table.
Insert indicates that the oracle engine fires the trigger whenever an insert statement a row from the table.
Update indicates that the oracle engine fires the trigger whenever an update statement changes a value in one of the columns from the table.

Create a transparent audit system for a table cust_mstr for a table. The system must keep track of the records that are being deleted or updated. The functionality being when a record is deleted or modified the original record details and the date of operation are stored in the audit table, then the delete or update operation is allowed to go through.

Audit Table
Customer Nome
First Name
Last Name

*/