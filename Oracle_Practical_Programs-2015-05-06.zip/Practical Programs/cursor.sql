/* The oracle engine uses a work area for its internal processing in order to execute an SQL statement. This work area is private to SQL's operations and is called a cursor.
The data that is stored in the cursor is called the active dataset. Conceptually the size of the cursor in memory is the size required to hold the number of rows in the active data set. Oracle has a predefined area in main memory set aside within which cursors are opened.
The value retrieved from a table are held in a cursor opened in memory by the oracle engine. This data is then transferred to the client machine via the network.

Types of cursor:
Cursors are classified depending on the circumstances under which they are opened. If the oracle engine opened a cursor for its internal processing it is known as an implicit cursor. A cursor can also be opened for processing data through a PL/SQL block on demand. Such a user defined curson is known as an explicit cursor. 
Both implicit and explicit cursors have 4 attributes:
	1. %isopen: Returns true if cursor is open.
	2. %found: Returns true if record was fetched successfully.
	3. %notfound: Returns true if record was not fetched successfully.
	4. %rowcount: Returns no. of records processed from the cursor.
	
The bank manager has decided to transfer employees across branches. Write a PL/SQL block to accept an employee number and the branch number followed by updating the branch number of that employee to which he belongs appropriately. Display an appropriate message using SQL %found based on the existence of the record in the emp_mstr table. Display an appropriate message using SQL %notfound based on the non-existence of the record in the emp_mstr table. */
SET SERVER OUTPUT ON

BEGIN

UPDATE EMP_MASTER SET BRANCH_NO=&BRANCH_NO WHERE EMP_NO=&EMP_NO;

IF SQL%FOUND THEN
	DBMS.OUTPUT.PUT_LINE('EMPLOYEE SUCCESSFULLY TRANSFERRED');
END IF;

IF SQL%NOTFOUND THEN
	DBMS.OUTPUT.PUT_LINE('EMPLOYEE NO. DOES NOT EXIST');
END IF;

END
/
