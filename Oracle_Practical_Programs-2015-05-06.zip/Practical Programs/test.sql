declare
num number; 
summ number;
temp number; 
re number;
begin

num:=153;---153 IS ARMSTRONG NUMBER
temp:=num;
summ := 0; 

while temp<>0 loop
re:=trunc(temp mod 10);
summ:=summ +(re*re*re);
temp:=temp/10;
end loop;

dbms_output.put_line(summ);

if summ=num then
dbms_output.put_line('number is aramstrong');
else
dbms_output.put_line('number is not aramstron');
end if;

end;
/