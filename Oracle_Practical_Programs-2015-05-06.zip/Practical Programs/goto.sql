--Write a PL/SQL Block of code to achieve the following:
--If there are no transactions taken place in the last 365 days then mark the account status as inactive, and then record the account number, the opening date and the type of account.
set serveroutput ON
DECLARE
mACCT_NO VARCHAR2(10);
mANS VARCHAR2(3);
mOPNDT DATE;
mTYPE VARCHAR2(2);
BEGIN
mACCT_NO:=&mACCT_NO;
SELECT 'YES' INTO mANS from TRANS_MASTR WHERE ACCT_NO = mACCT_NO GROUP BY ACCT_NO HAVING MAX(SYSDATE-DT)>365;
IF mANS='YES' THEN
	GOTO mark_status;
ELSE
	DBMS_OUTPUT.PUT_LINE('Account Number: '||mACCT_NO||'is Active');
END IF;
<<mark_status>>
UPDATE ACCT_MASTR SET STATUS='I' WHERE ACCT_NO=mACCT_NO;
SELECT OPENDT INTO mOPNDT FROM ACCT_MASTR WHERE ACCT_NO = mACCT_NO;
INSERT INTO INACTV_ACCT_MASTER(ACCT_NO,OPNDT) VALUES(mACCT_NO,mOPNDT);
DBMS_OUTPUT.PUT_LINE('Account Number: '||mACCT_NO||'is marked as Inactive');

END;
/