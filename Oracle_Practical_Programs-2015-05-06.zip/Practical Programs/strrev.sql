set serveroutput ON

DECLARE

given_number varchar(5):='5639';
str_length number(2);
inverted_number varchar(5);

BEGIN

str_length := length(given_number);

FOR cntr IN REVERSE 1..str_length
LOOP
inverted_number:=inverted_number||substr(given_number,cntr,1);
END LOOP;

DBMS_OUTPUT.PUT_LINE('The given number is: '||given_number);
DBMS_OUTPUT.PUT_LINE('The inverted number is: '||inverted_number);
--comment																																					
END;
/