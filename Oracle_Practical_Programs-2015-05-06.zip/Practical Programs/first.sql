DECLARE

A NUMBER(5,2) := 12.54;
B NUMBER(5,2) := 11.23;
SUM1 NUMBER(6,2);

BEGIN

SUM1 := A+B;

DBMS_OUTPUT.PUT_LINE('THE SUM IS: '||SUM1);

--comment																																					
END;
/