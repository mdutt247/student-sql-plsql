Another technique commonly used to control the loop...end loop within a PL/SQL block is the for variable in value construct. This is an example of a machine defined loop exit i.e when all the values in the for construct are exhausted looping stops.

Syntax:

FOR VARIABLE IN CURSOR_NAME

HERE FOR AUTOMATICALLY CREATES the memory variable of the %ROWTYPE. Each record in the opened cursor becomes a value for the memory variable of the %ROWTYPE.

The for verb ensures that a row from the cursor is loaded in the declared memory variable and the loop executes once. This goes on until all the rows of the cursor have been loaded into the memory variable. After this the loop stops.

A cursor for loop automatically does the following:
	1. Implicitly declares its loop index as a %rowtype record.
	2. Opens a cursor 
	3. Fetches a row from the cursor for each loop iteration.
	4. Closes the cursor when all rows have been processed.

A cursor can be closed when an exit or goto statement is used to leave the loop prematurely or if an exception is raised inside the loop.