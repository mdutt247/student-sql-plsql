/* Procedures / Functions:
It is a logically grouped set of SQL and PL/SQL statements that perform a specific task. A stored procedure or function is a named PL/SQL code block that has been compiled and stored in one of the oracle engines system tables.
To make a procedure or function dynamic either of them can be passed parameters before execution. A procedure or function can then change the way it works depending on the parameters passed prior to its execution.

Procedures and functions are made up of:
										1. A declaring part
										2. An executable part
										3. An optional exceptional handling part

Advantages of using a procedure or function:
										1. Security
										2. Performance
										3. Memory Allocation
										4. Productivity
										5. Integrity
	
Procedure vs. Functions:

1. A function must return a value back to the column. A function can return only one value to calling PL/SQL code block.
2. By defining multiple out parameters in a procedure multiple values can caller. The out variable being global by nature, its value is accessible by any PL/SQL code block including the PL/SQL block via which it was called.

Stored Procedure:
create or replace procedure [shcema] <proceduredName>
(<Argument> {IN, OUT, IN OUT} <Data type>,....) {IS, AS}
<variable> declarations,
<constant> declarations,
Begin
	<PL/SQL subprogram body>,
Exception
	<Exception PL/SQL black>,
End;

---------

Replace		Recreates the procedure if it already exists. This option is used to change the definition of an existing procedure without dropping, recreating and regranting object privilages previously granted on it. If a procedure is redefined the oracle engine recompiles it.
Schema		to contain the procedure.
Procedure	It is the name of the procedure to be created.
Argument	It is the name of an  argument to the procedure. Parenthesis can be ommited if no arguments are present.
IN			Indicates that the parameter will accept a value from the user.
OUT			Indicates that the parameter will return a value to the user.
IN OUT		Indicates that the parameter will either accept a value from the user or return a value to the user.
Datatype	It is the datatype of an argument. It supports any datatype supported by PL/SQL.

---------

Function	

create or replace function [schema] <functionName>
(<Argument> IN <Data type>,....) return <Data type>{IS, AS}
<variable> declarations,
<constant> declarations,
Begin
	<PL/SQL subprogram body>,
Exception
	<Exception PL/SQL black>,
End;


Return <data type>	It is the datatype of the functions return value because every function must return a value, this clause is required.
---------
 */
create or replace function ECheckAcctNo(vAcct_No IN varchar2)
	return number IS
Begin
	select distinct Acct_No into dummyAcctNo from Trans_Mstr where Acct_No = vAcct_No;
	return 1;
Exception
	when No_Data_Found then return 0;
End;