A package is an Oracle object which holds other objects within it. Objects commonly held within a package are procedures, functions, variables, constants, cursors and exceptions. A package once retained and debugged is compiled and stored in Oracles system tables held in an oracle database. All users who have execute permission on the oracle database can then use the package.

Components of an Oracle package 

A package has usually two components a specification and a body. A package specification declares the types (variables of the record type) memory variables, constants, exceptions, cursors and sub-programs that are available for use.

Package Specification

The package specification contains:
	1. Name of the package
	2. Name of the datatype of any arguments
	3. This declaration is local to the datatype and global to the package
	
This means that procedures, functions, variables, constant, cursors and exceptions and other objects declared in a package are accessible from anywhere in the package. Therefore, all the information a package needs to execute a sub-program is content in the package specification itself.

Example:

Create Package bnk_pck_spec IS
Function F_Chkacct

The package body

The body of the package contains the definition of public objects that are declared in the specification. The body can also contain other objects declarations that are private to the package. The objects declared directly in the package body are not accessible to other objects outside the package.

Create or Replace Package Transaction_Mgmt AS
	Procedure Perform_Trans(mAcct_No varchar2, MD varchar2, Amt, Number);
	Procedure Cancle_Fd(mFd_No varchar2);
	Bal Number;
	P_Acct_No varchar2(10);
	D_Amt Numberl
End Transaction_Mgmt;

Create or Replace Package Body Transaction_Mgmt AS
	Procedure Perform_Trans(mAcct_No varchar2, MD varchar2, Amt Number) iS
	BEGIN
	Select curbal into bal from Acct_Mstr Where Acct_No=mAcct_No;
	If MD='D' Then
	Insert into Trans_Mstr(Trans_no, Acct_no, DT, Type, Particular, DR_CR, Amt, Balance)
	values(Select 'T' || To_Char(Max
	