--Write a PL/SQL block of code such that depending upon a user supplied account number, the customer to whom the account belongs, 
--the introducer of that account and the nominee of that account are inserted into the Acct_Cust_Intro_Num. 
--If the user enters an account number that is not in the Acct_Mstr table then the PL/SQL block must display appropriate error message back to the user.
--
set serveroutput ON

DECLARE
mAcct_No NUMBER(10);
mCheck VARCHAR2(10);
mCust_No VARCHAR2(10);
mIntro_Cust_No varchar2(10);
mNominee_No varchar2(10);

BEGIN
mAcct_No:=&mAcct_No;
SELECT 'YES' into mCheck from acct_master where Acct_No=mAcct_No;

EXCEPTION
WHEN NO_DATA_FOUND THEN
	DBMS_OUTPUT.PUT_LINE('Account Number does not Exist!');
	
IF mCheck='YES' THEN
mCust_No:='&mCust_No';
mIntro_Cust_No:='&mIntro_Cust_No';
mNominee_No:='&mNominee_No';

INSERT INTO Acct_Cust_Intro_Num(Acct_No, Cust_No, Intro_Cust_No, Nominee_No) values(mAcct_No, mCust_No, mIntro_Cust_No, mNominee_No);
DBMS_OUTPUT.PUT_LINE('Data Inserted Successfully!');

END IF;


END;
/