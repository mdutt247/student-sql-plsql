set serveroutput ON

DECLARE

mCur_Bal number(11,2);
mAcct_No varchar2(7);
mFine number(4):=100;
mMin_Bal constant number(7,2):=5000.00;

BEGIN

mAcct_No:=&mAcct_No;
SELECT cur_bal into mCur_Bal from Acct_Master where acct_no=mAcct_No;

if mCur_Bal<mMin_Bal then 
UPDATE Acct_Master SET cur_bal=cur_bal-mFine where acct_no=mAcct_No;
end if;

SELECT cur_bal into mCur_Bal from Acct_Master where acct_no=mAcct_No;
DBMS_OUTPUT.PUT_LINE('THE Account Balance IS: '||mCur_Bal);

--comment																																					
END;
/