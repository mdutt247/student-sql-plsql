/* A cursor thus created and used is known as an explicit cursor.

The steps involved in using an explicit cursor and manipulating data in its active set are:
	
	1. Declare a cursor mapped to a SQL Select statement that retrieves data for processing
	2. Open the cursor.
	3. Fetch data from the cursor one row at a time into memory variables.
	4. Process the data held in the memory variables as required using a loop.
	5. Exit from the loop after processing is complete.
	6. Close the cursor.
	
A bank manager has decided to mark all those accounts as inactive(I) on which there are no transactions performed in the last 365 days. Whenever any such update takes place a record for the same is maintained in the INSTV_ACCT_MSTR table comprising the account number, the opening date and the type of account. Write a PL/SQL block to do the same.
 */
 
SET SERVER OUTPUT ON

DECLARE
	
	CURSOR CRSR_NOTRANS IS
		SELECT ACCT_NO, STATUS, OPNDT, TYPE FROM
		ACCT_MSTR WHERE ACCT_NO IN(SELECT ACCT_NO FROM
		TRANS_MASTR GROUP BY ACCT_NO HAVING MAX(SYSDATE-DT)>365);
	
	STR_ACCT_NO ACCT_MSTR.ACCT_NO%TYPE;
	STR_STATUS ACCT_MSTR.STATUS%TYPE;
	DT_OPENDT ACCT_MSTR.OPENDT%TYPE;
	STR_TYPE ACCT_MSTR.TYPE%TYPE;
	
BEGIN
	
	OPEN CRSR_NOTRANS;
	
	IF CRSR_NOTRANS %ISOPEN THEN
		LOOP
			FETCH CRSR_NOTRANS INTO STR_ACCT_NO,STR_STATUS,DT_OPENDT, STR_TYPE;
		EXIT WHEN CRSR_NOTTRANS%NOTFOUND;
		
		IF CRSR_NOTRANS%FOUND THEN
			UPDATE ACCT_MSTR SET STATUS='I' WHERE ACCT_NO=STR_ACCT_NO;
			INSERT INTO INACTV_ACCT_MASTR VALUES(STR_ACCT_NO,DT_OPNDT,STR_TYPE);
		END IF;
		END LOOP;
		COMMIT;
	ELSE
	DBMS_OUTPUT.PUT_LINE('UNABLE TO OPEN CURSOR');
	END IF;
	
	CLOSE CRSR_NOTRANS;
	
END;
/
	
		